﻿namespace Project
{
    partial class Add_Memers
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Add_Memers));
            this.Ad_Adres_TextBox = new System.Windows.Forms.RichTextBox();
            this.Ad_F_Name_textBox = new System.Windows.Forms.TextBox();
            this.add_member_Name_textBox = new System.Windows.Forms.TextBox();
            this.Ad_Cnic_textBox = new System.Windows.Forms.TextBox();
            this.Ad_phpne_textBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Recordgridview = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Gender = new System.Windows.Forms.ComboBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblValidateCNIC = new System.Windows.Forms.Label();
            this.phonerror = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Recordgridview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Ad_Adres_TextBox
            // 
            this.Ad_Adres_TextBox.Location = new System.Drawing.Point(83, 237);
            this.Ad_Adres_TextBox.Name = "Ad_Adres_TextBox";
            this.Ad_Adres_TextBox.Size = new System.Drawing.Size(253, 47);
            this.Ad_Adres_TextBox.TabIndex = 28;
            this.Ad_Adres_TextBox.Text = "";
            // 
            // Ad_F_Name_textBox
            // 
            this.Ad_F_Name_textBox.Location = new System.Drawing.Point(460, 126);
            this.Ad_F_Name_textBox.Name = "Ad_F_Name_textBox";
            this.Ad_F_Name_textBox.Size = new System.Drawing.Size(253, 20);
            this.Ad_F_Name_textBox.TabIndex = 16;
            // 
            // add_member_Name_textBox
            // 
            this.add_member_Name_textBox.Location = new System.Drawing.Point(83, 126);
            this.add_member_Name_textBox.Name = "add_member_Name_textBox";
            this.add_member_Name_textBox.Size = new System.Drawing.Size(253, 20);
            this.add_member_Name_textBox.TabIndex = 15;
            // 
            // Ad_Cnic_textBox
            // 
            this.Ad_Cnic_textBox.Location = new System.Drawing.Point(83, 183);
            this.Ad_Cnic_textBox.Name = "Ad_Cnic_textBox";
            this.Ad_Cnic_textBox.Size = new System.Drawing.Size(253, 20);
            this.Ad_Cnic_textBox.TabIndex = 17;
            this.Ad_Cnic_textBox.TextChanged += new System.EventHandler(this.Ad_Cnic_textBox_TextChanged);
            this.Ad_Cnic_textBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Ad_Cnic_textBox_KeyUp);
            // 
            // Ad_phpne_textBox
            // 
            this.Ad_phpne_textBox.Location = new System.Drawing.Point(460, 183);
            this.Ad_phpne_textBox.Name = "Ad_phpne_textBox";
            this.Ad_phpne_textBox.Size = new System.Drawing.Size(253, 20);
            this.Ad_phpne_textBox.TabIndex = 18;
            this.Ad_phpne_textBox.TextChanged += new System.EventHandler(this.Ad_phpne_textBox_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Narrow", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(241, 347);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(260, 42);
            this.label9.TabIndex = 27;
            this.label9.Text = "Member\'s Record";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(457, 217);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 16);
            this.label8.TabIndex = 26;
            this.label8.Text = "Gender";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(80, 217);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 16);
            this.label7.TabIndex = 25;
            this.label7.Text = "Adress";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(457, 167);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 16);
            this.label6.TabIndex = 24;
            this.label6.Text = "Phone";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(80, 166);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 16);
            this.label5.TabIndex = 23;
            this.label5.Text = "Cnic";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(457, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 16);
            this.label4.TabIndex = 22;
            this.label4.Text = "F_Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(80, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 16);
            this.label3.TabIndex = 21;
            this.label3.Text = "Name";
            // 
            // Recordgridview
            // 
            this.Recordgridview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Recordgridview.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.Recordgridview.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.Recordgridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Recordgridview.Location = new System.Drawing.Point(0, 403);
            this.Recordgridview.Name = "Recordgridview";
            this.Recordgridview.ReadOnly = true;
            this.Recordgridview.Size = new System.Drawing.Size(819, 240);
            this.Recordgridview.TabIndex = 20;
            this.Recordgridview.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Recordgridview_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(310, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 31);
            this.label1.TabIndex = 29;
            this.label1.Text = "Add Member\'s";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(612, 301);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 38);
            this.button1.TabIndex = 30;
            this.button1.Text = "ADD Member";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Gender
            // 
            this.Gender.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.Gender.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.Gender.CausesValidation = false;
            this.Gender.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Gender.FormattingEnabled = true;
            this.Gender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.Gender.Location = new System.Drawing.Point(460, 237);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(253, 21);
            this.Gender.TabIndex = 31;
            this.Gender.Text = "Male";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(282, 49);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(122, 35);
            this.pictureBox2.TabIndex = 32;
            this.pictureBox2.TabStop = false;
            // 
            // lblValidateCNIC
            // 
            this.lblValidateCNIC.AutoSize = true;
            this.lblValidateCNIC.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidateCNIC.Location = new System.Drawing.Point(342, 184);
            this.lblValidateCNIC.Name = "lblValidateCNIC";
            this.lblValidateCNIC.Size = new System.Drawing.Size(36, 16);
            this.lblValidateCNIC.TabIndex = 33;
            this.lblValidateCNIC.Text = "Invaild";
            this.lblValidateCNIC.Visible = false;
            // 
            // phonerror
            // 
            this.phonerror.AutoSize = true;
            this.phonerror.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phonerror.Location = new System.Drawing.Point(719, 185);
            this.phonerror.Name = "phonerror";
            this.phonerror.Size = new System.Drawing.Size(36, 16);
            this.phonerror.TabIndex = 33;
            this.phonerror.Text = "Invaild";
            this.phonerror.Visible = false;
            // 
            // Add_Memers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.phonerror);
            this.Controls.Add(this.lblValidateCNIC);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Ad_Adres_TextBox);
            this.Controls.Add(this.Ad_F_Name_textBox);
            this.Controls.Add(this.add_member_Name_textBox);
            this.Controls.Add(this.Ad_Cnic_textBox);
            this.Controls.Add(this.Ad_phpne_textBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Recordgridview);
            this.Name = "Add_Memers";
            this.Size = new System.Drawing.Size(819, 643);
            this.Load += new System.EventHandler(this.Add_Memers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Recordgridview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox Ad_Adres_TextBox;
        private System.Windows.Forms.TextBox Ad_F_Name_textBox;
        private System.Windows.Forms.TextBox add_member_Name_textBox;
        private System.Windows.Forms.TextBox Ad_Cnic_textBox;
        private System.Windows.Forms.TextBox Ad_phpne_textBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView Recordgridview;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox Gender;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lblValidateCNIC;
        private System.Windows.Forms.Label phonerror;
    }
}
